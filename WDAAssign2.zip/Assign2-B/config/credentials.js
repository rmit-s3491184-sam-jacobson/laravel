/**
 * MongoDB credentials
 * You may add connection string for production environment
 */

module.exports = {
    mongo: {
        development: {
            connectionString: 'mongodb://wdauser:1234567@ds041924.mlab.com:41924/wdaassign1'
        }
    }
}