@extends('layouts.master')

@section('content')
    <div class="row">
        <div class="col-lg-12 margin-tb">
            <div class="pull-left">
                <h2> Show Wishlist</h2>
            </div>
            <div class="pull-right">
                <a class="btn btn-primary" href="{{ route('wishlist.index') }}"> Back</a>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
            <strong>Name:</strong>
            {{ $product->user_name}}
        </div>
        </div>
        <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                <strong>Movie:</strong>
                {{ $product->movie_title}}
            </div>
        </div>
    </div>
@endsection