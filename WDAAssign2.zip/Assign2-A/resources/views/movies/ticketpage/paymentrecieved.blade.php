@extends('layouts.master')

@section('content')
    {{--<script src="{{URL::asset('js\ajax-crud.js')}}"></script>--}}
    <div class="container">
        <br>
        <br>
        <br>
        <h1>Thank You! </h1>
        <h2>Your payment has been recieved!</h2>
        <p>Now you can view your tickets in "MyBooking"</p>
    </div>
@endsection

