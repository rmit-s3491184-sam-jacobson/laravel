@extends('layouts.master')

@section('content')
    {{--<script src="{{URL::asset('js\ajax-crud.js')}}"></script>--}}
    <div class="container">
        <h3>Payment denied!</h3>
        <p>Check your input! </p>
    </div>
@endsection