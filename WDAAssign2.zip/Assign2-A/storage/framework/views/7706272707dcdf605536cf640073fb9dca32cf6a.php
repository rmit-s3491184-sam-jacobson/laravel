

<?php $__env->startSection('content'); ?>
    <?php /*<script src="<?php echo e(URL::asset('js\ajax-crud.js')); ?>"></script>*/ ?>
    <div id="feature">
        <div class="container">
            <div class="row">
                <div class="col-sm-4">
            <h2>Your Items:</h2>
                <h4>Movie: <?php echo e($movieTitle->title); ?></h4>
                <h4>Cinema: <?php echo e($cinemaDetails->name); ?></h4>
                <h4>Date/Time: <?php echo e($session->session_time); ?> </h4>
                <h4>Number of tickets: <?php echo e($formData['count']); ?></h4>
                <h4>Total cost: $<?php echo e($cost); ?></h4>
            </div>

            <div class="col-sm-4">
            <?php echo Form::open(array('action'=>'PaymentPageController@paymentrecieved', 'files'=>true)); ?>

            <label>Select a payment type:</label><br>
            <select id = "paytype" name = "paytype">
                <option value="Visa">Visa</option>
                <option value="Mastercard">Mastercard</option>
            </select>
            <br>
            <label>Enter your credit card number:</label><br>
            <input type="text" name="cardNo" id="cardNo"><br>
            <label>Enter your CVV (3 numbers on the back of your card):</label><br>
            <input type="text" name="CVV" id="CVV"><br>
            <label>Enter your full name:</label><br>
            <input type="text" name="name" id="name"><br>
            <label>Enter your address:</label><br>
            <input type="text" name="address" id="address"><br>
            <button>checkout</button>
            </div>
            </div>
            <?php echo Form::close(); ?>

        </div>
    </div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>