<?php $__env->startSection('content'); ?>

    <?php if($message = Session::get('success')): ?>
        <div class="alert alert-success">
            <p><?php echo e($message); ?></p>
        </div>
    <?php endif; ?>
    <table class="table table-striped">
        <thead>
        <tr>

            <th>Odrer ID</th>
            <th>Movie</th>
            <th>Cinema</th>
            <th>Session</th>
            <th>Type</th>
            <th>Quantity</th>
        </tr>
        </thead>

        <tbody>

        <?php foreach($tickets as $ticket): ?>

            <tr>
                <?php /*<td><?php echo e(++$i); ?></td>*/ ?>
                <td><?php echo e($ticket->id); ?></td>
                <td><?php echo e($ticket->movieName); ?></td>
                <td><?php echo e($ticket->cinemaName); ?></td>
                <td><?php echo e($ticket->sessionTime); ?></td>
                <td><?php echo e($ticket->type); ?></td>
                <td><?php echo e($ticket->qty); ?></td>

            </tr>
        <?php endforeach; ?>
        </tbody>


    </table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>