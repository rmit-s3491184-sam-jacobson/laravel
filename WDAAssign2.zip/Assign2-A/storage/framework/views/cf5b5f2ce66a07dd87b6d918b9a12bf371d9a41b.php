<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-12">
            <h1>Movies</h1>
            <?php if(session('status')): ?>
                <div class="alert alert-success">
                    <?php echo e(session('status')); ?>

                </div>
            <?php endif; ?>
            <a href="movie/create" class="btn btn-primary btn-raised">Create</a>

            <table id="example" class="table table-striped">
                <thead>
                <tr>
                    <th>Title</th>
                    <th>Description</th>
                    <th>Image</th>
                    <th>Minutes</th>
                    <th>Actors</th>
                    <th>Directors</th>
                    <th>Classification</th>
                    <th>Action</th>

                </tr>
                </thead>
                <tfoot>
                <tr>
                    <th>Title</th>
                    <th>Description</th>
                    <th>Image</th>
                    <th>Minutes</th>
                    <th>Actors</th>
                    <th>Directors</th>
                    <th>Classification</th>
                    <th>Action</th>
                </tr>
                </tfoot>
                <tbody>
                <?php foreach($movies as $movie): ?>

                    <tr>
                        <th><?php echo e($movie->title); ?></th>
                        <th><?php echo e($movie->description); ?></th>
                        <th><?php echo e($movie->image); ?></th>
                        <th><?php echo e($movie->minutes); ?></th>
                        <th><?php echo e($movie->actors); ?></th>
                        <th><?php echo e($movie->directors); ?></th>
                        <th><?php echo e($movie->classification); ?></th>
                        <th><?php echo link_to_action('Admin\MovieController@edit', 'Edit', $movie->id); ?>

                            | <?php echo link_to_action('Admin\MovieController@destroy','Remove', $movie->id); ?></th>
                    </tr>
                <?php endforeach; ?>


                </tbody>
            </table>
            <div class="divider"></div>
            <a href="dashboard" class="btn btn-default btn-raised">Back</a>
        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>