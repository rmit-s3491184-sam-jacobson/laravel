

<?php $__env->startSection('content'); ?>


    <div class="container">
        <div class="row">
            <div class="col-sm-4">
                <h2><?php echo e($movie->title); ?></h2>
                <img src="/WDAAssign2/Assign2-A/<?php echo e($movie->image); ?>" height="200" width="150">
                <p><?php echo e($movie->description); ?></p>
            </div>
            <div class="col-sm-4">
            <h2>Purchase tickets!</h2>
                <form action="action_page.php">
                    Select a Cinema:<br>
                    <select>
                        <?php foreach($cinemas as $cinema): ?>
                            <option value="<?php echo e($cinema->id); ?>"><?php echo e($cinema->cinema); ?></option>
                        <?php endforeach; ?>
                    </select>
                    <br>
                    Select a session:
                    <br>
                    <select>
                        <?php foreach($sessions as $session): ?>
                            <option value="<?php echo e($session->id); ?>"><?php echo e($session->time); ?></option>
                        <?php endforeach; ?>
                    </select>
                    <br>
                    Number of tickets:<br>
                    <select>
                        <?php for($i = 1; $i < 10; $i++): ?>
                            <option value="<?php echo e($i); ?>"><?php echo e($i); ?></option>
                        <?php endfor; ?>
                    </select>
                    <br><br>
                    <input type="submit" value="Submit">
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>