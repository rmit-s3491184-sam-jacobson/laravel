<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-lg-12 margin-tb">
            <div class="pull-left">
                <h2>Your Wish List</h2>
            </div>
            <div class="pull-right">
                <a class="btn btn-success" href="<?php echo e(route('wishlist.create')); ?>"> Add Movie To Wish List</a>
            </div>
        </div>
    </div>
    <?php if($message = Session::get('success')): ?>
        <div class="alert alert-success">
            <p><?php echo e($message); ?></p>
        </div>
    <?php endif; ?>
    <table class="table table-bordered">
        <tr>
            <th>No</th>
            <th>Name</th>
            <th>Movie Title</th>
            <th width="280px">Action</th>
        </tr>
        <?php foreach($products as $product): ?>
            <tr>
                <td><?php echo e($product->id); ?></td>
                <td><?php echo e($product->user_name); ?></td>
                <td><?php echo e($product->movie_title); ?></td>
                <td>
                    <a class="btn btn-info" href="<?php echo e(route('wishlist.edit',$product->id)); ?>">Edit</a>
                    <?php echo Form::open(['method' => 'DELETE','route' => ['wishlist.destroy', $product->id],'style'=>'display:inline']); ?>

                    <?php echo Form::submit('Delete', ['class' => 'btn btn-danger']); ?>

                    <?php echo Form::close(); ?>

                </td>
            </tr>
        <?php endforeach; ?>
    </table>
    <?php echo $products->render(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>