<?php $__env->startSection('content'); ?>
    <?php /*<script src="<?php echo e(URL::asset('js\ajax-crud.js')); ?>"></script>*/ ?>
    <div class="container">
        <br>
        <br>
        <br>
        <h1>Thank You! </h1>
        <h2>Your payment has been recieved!</h2>
        <p>Now you can view your tickets in "MyBooking"</p>
    </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>