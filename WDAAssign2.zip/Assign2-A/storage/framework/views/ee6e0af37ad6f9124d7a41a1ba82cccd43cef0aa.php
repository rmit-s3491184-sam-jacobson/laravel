<?php $__env->startSection('content'); ?>
    <?php /*<script src="<?php echo e(URL::asset('js\ajax-crud.js')); ?>"></script>*/ ?>
    <div class="container">
        <h3>Payment denied!</h3>
        <p>Check your input! </p>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>