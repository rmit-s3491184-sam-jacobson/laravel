<?php $__env->startSection('content'); ?>

    <div class="container">
        <ul class="nav nav-tabs">
            <li class="active"><a data-toggle="tab" href="#home">Now Showing</a></li>
            <li><a data-toggle="tab" href="#menu1">Coming Soon</a></li>
            <li><a data-toggle="tab" href="#menu2">Search</a></li>
        </ul>

        <div class="tab-content">
            <div id="home" class="tab-pane fade in active">
                <div id="feature">
                    <div class="container">
                        <?php foreach($movies as $movie): ?>
                            <?php if($movie->status == 'now showing'): ?>
                            <div class="row">
                                <div class="col-sm-4">

                                    <a href="<?php echo e(URL::to("movie/ticketpage/$movie->id)")); ?>"><h3><?php echo e($movie->title); ?></h3></a>
                                    <img src="/WDAAssign2/Assign2-A/<?php echo e($movie->image); ?>" height="200" width="150">
                                </div>
                                <div class="col-sm-4">
                                    <h3>Description</h3>
                                    <p><?php echo e($movie->description); ?></p>
                                </div>
                            </div>
                            <?php endif; ?>
                        <?php endforeach; ?>
                    </div>
                </div>
            </div>
            <div id="menu1" class="tab-pane fade">
                <div id="feature">
                <div class="row">
                        <div class="col-lg-12 margin-tb">
                            <div class="pull-left">
                                <h2>Your Wish List</h2>
                            </div>
                            <div class="pull-right">
                                <a class="btn btn-success" href="<?php echo e(route('wishlist.create')); ?>"> Add Movie To Wish List</a>
                            </div>
                        </div>
                    </div>
                    <div class="container">
                        <?php foreach($movies as $movie): ?>
                            <?php if($movie->status == 'coming soon'): ?>
                                <div class="row">
                                    <div class="col-sm-4">

                                        <h3><?php echo e($movie->title); ?></h3>
                                        <img src="/WDAAssign2/Assign2-A/<?php echo e($movie->image); ?>" height="200" width="150">
                                    </div>
                                    <div class="col-sm-4">
                                        <h3>Description</h3>
                                        <p><?php echo e($movie->description); ?></p>
                                    </div>
                                </div>
                            <?php endif; ?>
                        <?php endforeach; ?>
                    </div>
                </div>
            </div>
            <div id="menu2" class="tab-pane fade">
                <div id="feature">
                    <div class="container">

                        <?php echo Form::open(array('url' => 'movie/searchResult', 'method' => 'GET')); ?>

                            <p>Search by Movie</p>
                             <?php echo Form::text('Search'); ?>

                             <?php echo Form::submit('Click Me!'); ?>

                        <?php echo Form::close(); ?>


                        <?php echo Form::open(array('url' => 'movie/searchResult', 'method' => 'POST')); ?>

                        <p>Search by Cinema</p>
                        <?php echo Form::text('Search'); ?>

                        <?php echo Form::submit('Click Me!'); ?>

                        <?php echo Form::close(); ?>

                    </div>
                </div>
            </div>

        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>