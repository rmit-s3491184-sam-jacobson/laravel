<?php $__env->startSection('content'); ?>
    <div id="feature">
        <div class="container">
            <?php if(!empty($movie)): ?>
                <?php if($movie[0]['status'] == 'now showing'): ?>
                    <div class="row">
                        <div class="col-sm-4">
                            <a href="<?php echo e(URL::to("movie/ticketpage/{$movie[0]['id']}")); ?>"><h3><?php echo e($movie[0]['title']); ?></h3></a>
                            <img src="/WDAAssign2/Assign2-A/<?php echo e($movie[0]['image']); ?>" height="200" width="150">
                        </div>
                        <div class="col-sm-4">
                            <h3>Description</h3>
                            <p><?php echo e($movie[0]['description']); ?></p>
                        </div>
                    </div>
                <?php else: ?>
                    <div class="row">
                        <div class="col-sm-4">
                            <h3><?php echo e($movie[0]['title']); ?></h3>
                            <img src="/WDAAssign2/Assign2-A/<?php echo e($movie[0]['image']); ?>" height="200" width="150">
                        </div>
                        <div class="col-sm-4">
                            <h3>Description</h3>
                            <p><?php echo e($movie[0]['description']); ?></p>
                        </div>
                    </div>
                <?php endif; ?>
            <?php else: ?>
                <div class="row">
                    <div class="col-sm-4">
                        <p>Search did not return any results</p>
                    </div>
                </div>
            <?php endif; ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>