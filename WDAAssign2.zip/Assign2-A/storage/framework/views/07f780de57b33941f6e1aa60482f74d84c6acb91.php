<?php $__env->startSection('content'); ?>
    <div id="feature">
        <div class="container">
            <?php echo e(var_dump($cinema)); ?>

            <?php if($movie != 1): ?>
                <?php foreach(json_decode($movie, true) as $mov): ?>
                    <?php if($mov['status'] == 'now showing'): ?>
                        <div class="row">
                            <div class="col-sm-4">
                                <a href="<?php echo e(URL::to("movie/ticketpage/{$mov['id']}")); ?>"><h3><?php echo e($mov['title']); ?></h3></a>
                                <img src="/WDAAssign2/Assign2-A/<?php echo e($mov['image']); ?>" height="200" width="150">
                            </div>
                            <div class="col-sm-4">
                                <h3>Description</h3>
                                <p><?php echo e($mov['description']); ?></p>
                            </div>
                        </div>
                    <?php elseif($mov['status'] == 'coming soon'): ?>
                        <div class="row">
                            <div class="col-sm-4">
                                <h3><?php echo e($mov['title']); ?></h3>
                                <img src="/WDAAssign2/Assign2-A/<?php echo e($mov['image']); ?>" height="200" width="150">
                            </div>
                            <div class="col-sm-4">
                                <h3>Description</h3>
                                <p><?php echo e($mov['description']); ?></p>
                            </div>
                        </div>
                    <?php endif; ?>
                <?php endforeach; ?>
            <?php elseif($cinema != 1): ?>
                <?php foreach(json_decode($cinema, true) as $c): ?>
                     <div class="row">
                         <div class="col-sm-4">
                             <h3><?php echo e($c['name']); ?></h3>

                         </div>
                         <div class="col-sm-4">
                             <h3>Address</h3>
                             <p><?php echo e($c['address']); ?></p>
                         </div>
                     </div>
                <?php endforeach; ?>
            <?php else: ?>
                <div class="row">
                    <div class="col-sm-4">
                        <h3>Search did not return any results</h3>
                    </div>
                </div>
            <?php endif; ?>

        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>