<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-12">
            <h1>Create Movie</h1>
            <?php echo Form::open(['url'=>'/admin/movie', 'files' => true]); ?>

            <div class="form-group">
                <?php echo Form::label('name', 'Title:'); ?>

                <?php echo Form::text('title', null, ['class' => 'form-control', 'placeholder' => 'Title']); ?>

            </div>

            <div class="form-group">
                <?php echo Form::label('name', 'Description:'); ?>

                <?php echo Form::textarea('description', null, ['class' => 'form-control', 'placeholder' => 'Description']); ?>

            </div>
            <div class="form-group">
                <?php echo Form::label('name', 'Image:'); ?>

                <?php echo Form::file('image', null); ?>

                <?php /*<?php echo Form::text('image', null, ['class' => 'form-control', 'placeholder' => 'Image']); ?>*/ ?>
            </div>

            <div class="form-group">
                <?php echo Form::label('name', 'Minutes:'); ?>

                <?php echo Form::text('minutes', null, ['class' => 'form-control', 'placeholder' => 'Minutes']); ?>

            </div>

            <div class="form-group">
                <?php echo Form::label('name', 'Actors:'); ?>

                <?php echo Form::textarea('actors', null, ['class' => 'form-control', 'placeholder' => 'Actors']); ?>

            </div>
            <div class="form-group">
                <?php echo Form::label('name', 'Directors:'); ?>

                <?php echo Form::text('directors', null, ['class' => 'form-control', 'placeholder' => 'Directors']); ?>

            </div>
            <div class="form-group">
                <?php echo Form::label('name', 'Classification:'); ?>

                <?php echo Form::text('classification', null, ['class' => 'form-control', 'placeholder' => 'Classification']); ?>

            </div>


            <?php echo Form::submit('Add Ticket', ['class'=>'btn btn-primary']); ?>

            <a href="../movies" class="btn btn-primary btn-raised">Cancel</a>
            <?php echo Form::close(); ?>


            <?php if($errors->any()): ?>
                <ul class="alert alert-danger">
                    <?php foreach($errors->all() as $error): ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; ?>
                </ul>
            <?php endif; ?>
            <div class="divider"></div>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>