<?php $__env->startSection('content'); ?>
    <?php /*<script src="<?php echo e(URL::asset('js\ajax-crud.js')); ?>"></script>*/ ?>
    <div class="container">
        <div class="row">
            <div class="col-md-6 col-xs-12">
                <h2><?php echo e($movie->title); ?></h2>
                <div class="row">
                <div class="col-md-6 col-xs-12">
                    <?php echo HTML::image($movie->image, null, array('height' => '200', 'width' => '150')); ?>

                </div>

                    <div class="col-md-6 col-xs-12">
                        <label>Running time</label>
                        <p><?php echo e($movie->minutes); ?></p>

                        <label>Classification</label>
                        <p><?php echo e($movie->classification); ?></p>
                    </div>

                </div>
                <h4>Description</h4>
                <p><?php echo e($movie->description); ?></p>
                <h4></h4>
            </div>
            <div class="col-md-4 col-xs-12">
                <h2>Purchase tickets!</h2>
                <?php echo Form::open(array('action'=>'MoviePageController@cart', 'files'=>true)); ?>

                <label>Select a Cinema:</label><br>
                <select class="form-control" id="cinema" name="cinema">
                    <option value="">Choose an option:</option>
                    <?php foreach($join as $cinema): ?>
                        <option value="<?php echo e($cinema->id); ?>"><?php echo e($cinema->name); ?></option>
                    <?php endforeach; ?>
                </select>
                <br>
                <label>Select a session:</label>
                <br>
                <select class="form-control" id="sesh" name="sesh">
                    <option value=""></option>
                </select>
                <br>
                <label>Type of ticket:</label>
                <br>
                <select class="form-control" id="ticket" name="ticket">
                    <?php foreach(\App\TicketType::all() as $tickets): ?>
                        <option value="<?php echo e($tickets->type); ?>"><?php echo e($tickets->type); ?> $<?php echo e($tickets->price); ?></option>
                        <?php endforeach; ?>

                </select>

                <br>
                <label>Number of tickets:</label><br>
                <select class="form-control" id="count" name="count">
                    <?php for($i = 1; $i < 10; $i++): ?>
                        <option value="<?php echo e($i); ?>"><?php echo e($i); ?></option>
                    <?php endfor; ?>
                </select>
                <br><br>
                <button type="submit" value="Submit">Add to Cart</button>
                <?php echo Form::close(); ?>

            </div>
        </div>
    </div>
    <script>
        $('#cinema').on('change', function (e) {
            console.log(e)
            var cinema_id = e.target.value;


            //ajax
            $.get('<?php echo e(url('/ajax-subcat')); ?>?cinema_id=' + cinema_id, function (data) {
                //success data
                console.log(data)
                $('#sesh').empty();
                $.each(data, function (index, subcatObj) {
                    $('#sesh').append('<option value="' + subcatObj.id + '">' + subcatObj.session_time + '</option>');
                    ;
                });
            });
        });
    </script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>