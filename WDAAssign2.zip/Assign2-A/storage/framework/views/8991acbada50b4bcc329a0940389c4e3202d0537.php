

<?php $__env->startSection('content'); ?>
    <?php /*<script src="<?php echo e(URL::asset('js\ajax-crud.js')); ?>"></script>*/ ?>
    <div class="container">
        <div class="row">
            <div class="col-sm-4">
                <h2><?php echo e($movie->title); ?></h2>
                <img src="/WDAAssign2/Assign2-A/<?php echo e($movie->image); ?>" height="200" width="150">
                <p><?php echo e($movie->description); ?></p>
            </div>
            <div class="col-sm-4">
            <h2>Purchase tickets!</h2>
            <?php echo Form::open(array('action'=>'MoviePageController@cart', 'files'=>true)); ?>

                    <label>Select a Cinema:</label><br>
                    <select id = "cinema" name = "cinema">
                        <option value="">Choose an option:</option>
                        <?php foreach($join as $cinema): ?>
                            <option value="<?php echo e($cinema->cinema_id); ?>"><?php echo e($cinema->name); ?></option>
                        <?php endforeach; ?>
                    </select>
                    <br>
                    <label>Select a session:</label>
                    <br>
                    <select id = "sesh" name = "sesh">
                        <option value=""></option>
                    </select>
                    <br>
                    <label>Type of ticket:</label>
                    <br>
                    <select id= ="ticket" name = "ticket">
                        <option value="adult">Adult</option>
                        <option value="concession">Concession</option>
                        <option value="children">Children</option>
                    </select>

                    <br>
                    <label>Number of tickets:</label><br>
                    <select id = "count" name ="count">
                        <?php for($i = 1; $i < 10; $i++): ?>
                            <option value="<?php echo e($i); ?>"><?php echo e($i); ?></option>
                        <?php endfor; ?>
                    </select>
                    <br><br>
                    <input type="submit" value="Submit">
                <?php echo Form::close(); ?>

            </div>
        </div>
    </div>
<script>
    $('#cinema').on('change', function(e){
        console.log(e)
        var cinema_id = e.target.value;



    //ajax
        $.get('<?php echo e(url('/ajax-subcat')); ?>?cinema_id=' + cinema_id, function(data){
        //success data
        console.log(data)
        $('#sesh').empty();
        $.each(data, function(index, subcatObj){
            $('#sesh').append('<option value="'+subcatObj.id+'">'+subcatObj.session_time+'</option>');;
         });
    });
    });
</script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>