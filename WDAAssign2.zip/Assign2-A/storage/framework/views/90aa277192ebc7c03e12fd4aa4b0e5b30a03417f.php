<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-12">
            <h1>Create Ticket</h1>
            <?php echo Form::open(['url'=>'/admin/ticket']); ?>

            <div class="form-group">
                <?php echo Form::label('name', 'Type:'); ?>

                <?php echo Form::text('type', null, ['class' => 'form-control', 'placeholder' => 'Type']); ?>

            </div>

            <div class="form-group">
                <?php echo Form::label('name', 'Price:'); ?>

                <?php echo Form::text('price', null, ['class' => 'form-control', 'placeholder' => 'Price eg. 19.00']); ?>

            </div>

            <?php echo Form::submit('Add Ticket', ['class'=>'btn btn-primary']); ?>

            <a href="../ticket" class="btn btn-primary btn-raised">Cancel</a>
            <?php echo Form::close(); ?>


            <?php if($errors->any()): ?>
                <ul class="alert alert-danger">
                    <?php foreach($errors->all() as $error): ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; ?>
                </ul>
            <?php endif; ?>
            <div class="divider"></div>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>