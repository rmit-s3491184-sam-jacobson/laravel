<?php $__env->startSection('content'); ?>
    <?php /*<script src="<?php echo e(URL::asset('js\ajax-crud.js')); ?>"></script>*/ ?>
    <div id="feature">
        <div class="container">
            <div class="row">
                <h2>Billing Details</h2>
                <?php /*<div class="col-sm-4">*/ ?>
                <?php /*<h2>Your Items:</h2>*/ ?>
                <?php /*<h4>Movie: <?php echo e($movieTitle->title); ?></h4>*/ ?>
                <?php /*<h4>Cinema: <?php echo e($cinemaDetails->name); ?></h4>*/ ?>
                <?php /*<h4>Date/Time: <?php echo e($session->session_time); ?> </h4>*/ ?>
                <?php /*<h4>Number of tickets: <?php echo e($formData['count']); ?></h4>*/ ?>
                <?php /*<h4>Total cost: $<?php echo e($cost); ?></h4>*/ ?>
                <?php /*</div>*/ ?>
                <?php if($errors->any()): ?>
                    <ul class="alert alert-danger">
                        <?php foreach($errors->all() as $error): ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; ?>
                    </ul>
                <?php endif; ?>
                <div class="col-sm-4">
                    <?php echo Form::open(array('action'=>'ShoppingCartController@store', 'files'=>true)); ?>

                    <label>Select a payment type:</label><br>
                    <select class="form-control" id="paytype" name="paytype">
                        <option value="Visa">Visa</option>
                        <option value="Mastercard">Mastercard</option>
                    </select>
                    <br>
                    <label>Enter your credit card number:</label><br>
                    <input class="form-control" type="text" name="cardNo" id="cardNo"><br>
                    <label>Enter your credit card expire date:(e.g. 03/2017)</label><br>
                    <input class="form-control" type="text" name="expire" id="expire"><br>
                    <label>Enter your CVV (3 numbers on the back of your card):</label><br>
                    <input class="form-control" type="text" name="CVV" id="CVV"><br>
                    <label>Enter your full name:</label><br>
                    <input class="form-control" type="text" name="name" id="name"><br>
                    <label>Enter your address:</label><br>
                    <input class="form-control" type="text" name="address" id="address"><br>
                    <button type="submit" class="btn ptn-primary">Pay now!</button>
                </div>
            </div>
            <?php echo Form::close(); ?>

        </div>
    </div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>