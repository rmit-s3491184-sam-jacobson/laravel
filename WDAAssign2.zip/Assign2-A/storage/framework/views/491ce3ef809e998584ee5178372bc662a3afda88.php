<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-12">
            <h1>Tickets</h1>
            <?php if(session('status')): ?>
                <div class="alert alert-success">
                    <?php echo e(session('status')); ?>

                </div>
            <?php endif; ?>
            <a href="ticket/create" class="btn btn-primary btn-raised">Create</a>

            <table id="example" class="display" cellspacing="0" width="100%">
                <thead>
                <tr>
                    <th>Type</th>
                    <th>Price</th>
                    <th>Action</th>
                </tr>
                </thead>
                <tfoot>
                <tr>
                    <th>Type</th>
                    <th>Price</th>
                    <th>Action</th>
                </tr>
                </tfoot>
                <tbody>
                <?php foreach($tickets as $ticket): ?>

                    <tr>
                        <th><?php echo e($ticket->type); ?></th>
                        <th><?php echo e($ticket->price); ?></th>

                        <th><?php echo link_to_action('Admin\TicketController@edit', 'Edit', $ticket->id); ?>

                            | <?php echo link_to_action('Admin\TicketController@destroy','Remove', $ticket->id); ?></th>
                    </tr>
                <?php endforeach; ?>


                </tbody>
            </table>
            <div class="divider"></div>
            <a href="dashboard" class="btn btn-default btn-raised">Back</a>
        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>